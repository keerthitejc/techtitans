export function deadlineBadge(days) {
  if (days < 0) return ["Expired", "b-gry"];
  const label = `${days} ${days === 1 ? "day" : "days"} left`;
  if (days <= 7) return [label, "b-red"];
  if (days <= 21) return [label, "b-amb"];
  return [label, "b-grn"];
}

export const money = (n) => (n ? `Rs. ${n.toLocaleString("en-IN")}/month` : "Unpaid");

export function eligibilityText(e, m) {
  const cg =
    e.cgpa === "none" ? "not required"
    : e.cgpa === "yes" ? `meets the ${m.min_cgpa} minimum`
    : e.cgpa === "no" ? `is below the ${m.min_cgpa} minimum`
    : `minimum is ${m.min_cgpa} (add your CGPA to check)`;
  const yr = e.year === "yes" ? "is eligible" : e.year === "no" ? `is not listed (${m.years.join("/")})` : "unknown";
  return `CGPA ${cg}; year ${yr}.`;
}
