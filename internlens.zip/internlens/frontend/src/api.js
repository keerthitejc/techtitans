// All calls to the FastAPI backend. The Vite dev server proxies /api to localhost:8000.
const TOKEN_KEY = "il_token";

export const token = {
  get: () => localStorage.getItem(TOKEN_KEY),
  set: (t) => localStorage.setItem(TOKEN_KEY, t),
  clear: () => localStorage.removeItem(TOKEN_KEY),
};

async function request(path, options = {}) {
  const headers = { ...(options.headers || {}) };
  if (!(options.body instanceof FormData)) headers["Content-Type"] = "application/json";
  const t = token.get();
  if (t) headers.Authorization = `Bearer ${t}`;
  const res = await fetch(`/api${path}`, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const detail = Array.isArray(data.detail) ? "Check the form fields and try again." : data.detail;
    throw new Error(detail || "Something went wrong. Try again.");
  }
  return data;
}

const body = (obj) => JSON.stringify(obj);

export const api = {
  signup: (f) => request("/auth/signup", { method: "POST", body: body(f) }),
  login: (f) => request("/auth/login", { method: "POST", body: body(f) }),
  me: () => request("/me"),
  saveSkills: (skills) => request("/me/skills", { method: "PUT", body: body({ skills }) }),
  suggest: (q, exclude) => request(`/skills?q=${encodeURIComponent(q)}&exclude=${encodeURIComponent(exclude.join(","))}`),
  parseText: (text) => request("/skills/parse", { method: "POST", body: body({ text }) }),
  uploadResume: (file) => {
    const fd = new FormData();
    fd.append("file", file);
    return request("/resume", { method: "POST", body: fd });
  },
  search: (params) => request("/search", { method: "POST", body: body(params) }),
  saved: () => request("/saved"),
  save: (id) => request(`/saved/${id}`, { method: "PUT" }),
  unsave: (id) => request(`/saved/${id}`, { method: "DELETE" }),
};
