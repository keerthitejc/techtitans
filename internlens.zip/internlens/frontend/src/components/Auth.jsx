import { useState } from "react";
import { api, token } from "../api.js";

export default function Auth({ onLogin }) {
  const [tab, setTab] = useState("in");
  const [f, setF] = useState({ name: "", email: "", password: "", year: 3, cgpa: "", branch: "" });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  async function submit() {
    setErr("");
    if (!/^\S+@\S+\.\S+$/.test(f.email.trim())) return setErr("Enter a valid email address.");
    if (f.password.length < 6) return setErr("Password needs at least 6 characters.");
    if (tab === "up" && !f.name.trim()) return setErr("Enter your name.");
    setBusy(true);
    try {
      const payload = { ...f, year: Number(f.year), cgpa: Number(f.cgpa) || 0 };
      const res = tab === "up" ? await api.signup(payload) : await api.login({ email: f.email, password: f.password });
      token.set(res.token);
      onLogin(res.user);
    } catch (e) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="auth">
      <div className="brand">
        <div className="logo">InternLens</div>
        <h1>Find internships that fit what you can already do.</h1>
        <p>Upload a resume or type your skills. See which notices you match, what you are missing, and which deadlines are close.</p>
      </div>
      <div className="panel">
        <div className="box" onKeyDown={(e) => e.key === "Enter" && submit()}>
          <div className="tabs">
            <button className={tab === "in" ? "on" : ""} onClick={() => { setTab("in"); setErr(""); }}>Log in</button>
            <button className={tab === "up" ? "on" : ""} onClick={() => { setTab("up"); setErr(""); }}>Create account</button>
          </div>
          {tab === "up" && <input className="in" placeholder="Full name" value={f.name} onChange={set("name")} aria-label="Full name" />}
          <input className="in" type="email" placeholder="College email" value={f.email} onChange={set("email")} aria-label="Email" />
          <input className="in" type="password" placeholder="Password" value={f.password} onChange={set("password")} aria-label="Password" />
          {tab === "up" && (
            <>
              <div className="row">
                <select className="in" style={{ flex: 1 }} value={f.year} onChange={set("year")} aria-label="Year of study">
                  {[1, 2, 3, 4].map((y) => <option key={y} value={y}>Year {y}</option>)}
                </select>
                <input className="in" style={{ flex: 1 }} placeholder="CGPA (optional)" value={f.cgpa} onChange={set("cgpa")} aria-label="CGPA" />
              </div>
              <input className="in" placeholder="Branch, e.g. CSE (optional)" value={f.branch} onChange={set("branch")} aria-label="Branch" />
            </>
          )}
          {err && <div className="err" role="alert">{err}</div>}
          <button className="btn" onClick={submit} disabled={busy}>{busy ? "Please wait..." : tab === "in" ? "Log in" : "Create account"}</button>
        </div>
      </div>
    </div>
  );
}
