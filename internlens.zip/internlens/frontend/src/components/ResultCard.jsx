import { useState } from "react";
import { deadlineBadge, eligibilityText, money } from "../utils.js";

const MARK = { ok: " ✓", rel: " ~", miss: " ✗" };

export default function ResultCard({ m, saved, onToggle, index }) {
  const [open, setOpen] = useState(false);
  const [label, cls] = deadlineBadge(m.days_left);
  const got = m.must.filter((x) => x.status === "ok").length;
  const rel = m.must.filter((x) => x.status === "rel").map((x) => x.skill);
  const miss = m.must.filter((x) => x.status === "miss").map((x) => x.skill);

  return (
    <div className="card new" style={{ animationDelay: `${Math.min(index, 12) * 30}ms` }}>
      <div className="row" style={{ justifyContent: "space-between" }}>
        <div>
          <h3>{m.title}</h3>
          <div className="mut">{m.org} · {m.city} · {m.mode} · {m.weeks} weeks · {money(m.stipend)}</div>
        </div>
        <div className="row">
          <span className={`badge ${cls}`}>{label}</span>
          <button className="btn ghost" aria-pressed={saved} onClick={onToggle}>{saved ? "Saved" : "Save"}</button>
        </div>
      </div>
      <div className="chips">
        <span className="chip">{m.fit}</span>
        {m.must.map((x) => <span key={x.skill} className={`chip ${x.status}`}>{x.skill}{MARK[x.status]}</span>)}
      </div>
      <div><button className="btn ghost" onClick={() => setOpen(!open)} aria-expanded={open}>{open ? "Hide explanation" : "Why this result"}</button></div>
      {open && (
        <div className="why">
          <div>
            <b>Required skills</b>: you have {got} of {m.must.length}.
            {rel.length > 0 && ` Related but not identical: ${rel.join(", ")} (the notice does not say a related skill is accepted).`}
            {miss.length > 0 && ` Missing: ${miss.join(", ")}.`}
          </div>
          <div><b>Eligibility</b>: {eligibilityText(m.eligibility, m)}</div>
          {m.citations?.skills && <div className="q">Source {m.id}: "{m.citations.skills}"</div>}
          {m.citations?.deadline && m.citations.deadline !== m.citations.skills && <div className="q">Deadline source: "{m.citations.deadline}"</div>}
          <div className="mut">Suitability is based on stated requirements only. It does not predict selection.</div>
        </div>
      )}
    </div>
  );
}
