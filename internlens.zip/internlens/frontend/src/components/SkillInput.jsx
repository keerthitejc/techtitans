import { useEffect, useState } from "react";
import { api } from "../api.js";

export default function SkillInput({ skills, setSkills }) {
  const [q, setQ] = useState("");
  const [sug, setSug] = useState([]);

  useEffect(() => {
    const t = setTimeout(() => api.suggest(q, skills).then(setSug).catch(() => setSug([])), 120);
    return () => clearTimeout(t);
  }, [q, skills]);

  const add = (list) => setSkills([...new Set([...skills, ...list])]);

  async function addTyped() {
    const text = q.trim();
    if (!text) return;
    try {
      const { skills: found } = await api.parseText(text);
      if (found.length) add(found);
      else if (sug[0]) add([sug[0]]);
    } catch { /* ignore */ }
    setQ("");
  }

  return (
    <div className="sec">
      <h3>Your skills</h3>
      <div className="chips">
        {skills.length ? skills.map((s) => (
          <span className="chip" key={s}>{s}<button aria-label={`Remove ${s}`} onClick={() => setSkills(skills.filter((x) => x !== s))}>×</button></span>
        )) : <span className="mut">No skills yet. Type one or upload a resume.</span>}
      </div>
      <div className="row">
        <input className="in" style={{ flex: 1 }} placeholder="Type a skill, e.g. Python, ML" value={q}
          onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && addTyped()} aria-label="Add skill" />
        <button className="btn" onClick={addTyped}>Add</button>
      </div>
      <div className="sug">{sug.slice(0, 6).map((s) => <button key={s} onClick={() => add([s])}>+ {s}</button>)}</div>
    </div>
  );
}
