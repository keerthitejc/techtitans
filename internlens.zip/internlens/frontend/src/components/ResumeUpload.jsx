import { useRef, useState } from "react";
import { api } from "../api.js";

export default function ResumeUpload({ onSkills }) {
  const ref = useRef();
  const [paste, setPaste] = useState("");
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);

  async function upload(e) {
    const file = e.target.files[0];
    if (!file) return;
    setBusy(true);
    setMsg("");
    try {
      const r = await api.uploadResume(file);
      onSkills(r.skills);
      setMsg(r.warning || `Found ${r.skills.length} skills in ${file.name}. Review them before searching.`);
    } catch (err) {
      setMsg(err.message);
    } finally {
      setBusy(false);
      e.target.value = "";
    }
  }

  async function fromText() {
    try {
      const r = await api.parseText(paste);
      onSkills(r.skills);
      setMsg(r.skills.length ? `Found ${r.skills.length} skills in the pasted text.` : "No known skills found in that text.");
    } catch (err) {
      setMsg(err.message);
    }
  }

  return (
    <div className="sec">
      <h3>Resume</h3>
      <div className="drop" role="button" tabIndex={0} onClick={() => ref.current.click()} onKeyDown={(e) => e.key === "Enter" && ref.current.click()}>
        {busy ? "Reading resume..." : "Upload resume (PDF, DOCX or TXT)"}
      </div>
      <input ref={ref} type="file" accept=".pdf,.docx,.txt,.md" hidden onChange={upload} />
      <textarea className="in" rows={3} placeholder="Or paste resume text here" value={paste} onChange={(e) => setPaste(e.target.value)} aria-label="Paste resume text" />
      <button className="btn ghost" onClick={fromText}>Extract skills</button>
      {msg && <div className="mut" role="status">{msg}</div>}
    </div>
  );
}
