import { useEffect, useRef, useState } from "react";
import { api } from "../api.js";
import SkillInput from "./SkillInput.jsx";
import ResumeUpload from "./ResumeUpload.jsx";
import ResultCard from "./ResultCard.jsx";

const STEPS = ["Reading your skills", "Searching notices", "Ranking by evidence"];
const PAGE = 20;

export default function Dashboard({ user, onLogout, theme, setTheme }) {
  const [skills, setSkills] = useState(user.skills || []);
  const [res, setRes] = useState(null);
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(0);
  const [err, setErr] = useState("");
  const [tab, setTab] = useState("res");
  const [saved, setSaved] = useState([]);
  const [f, setF] = useState({ mode: "all", sort: "fit", method: "hybrid", paid_only: false, hide_expired: true });
  const [limit, setLimit] = useState(PAGE);
  const first = useRef(true);

  useEffect(() => { api.saved().then(setSaved).catch(() => {}); }, []);
  useEffect(() => { api.saveSkills(skills).catch(() => {}); }, [skills]);

  async function search(nextLimit = PAGE, nextF = f) {
    if (!skills.length) return setErr("Add at least one skill first.");
    setErr(""); setLoading(true); setTab("res"); setLimit(nextLimit);
    let s = 0;
    const iv = setInterval(() => setStep(++s % STEPS.length), 140);
    try {
      const [r] = await Promise.all([
        api.search({ skills, ...nextF, limit: nextLimit }),
        new Promise((ok) => setTimeout(ok, 350)), // keep the spinner visible briefly
      ]);
      setRes(r);
    } catch (e) {
      setErr(e.message);
    } finally {
      clearInterval(iv); setLoading(false);
    }
  }

  // Re-run automatically when filters change (after the first search).
  useEffect(() => {
    if (first.current) { first.current = false; return; }
    if (res) search(PAGE, f);
  }, [f]); // eslint-disable-line

  const isSaved = (id) => saved.some((m) => m.id === id);
  async function toggle(m) {
    if (isSaved(m.id)) { setSaved(saved.filter((x) => x.id !== m.id)); await api.unsave(m.id); }
    else { setSaved([...saved, m]); await api.save(m.id); }
  }
  const setFilter = (k) => (e) => setF({ ...f, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value });
  const list = tab === "saved" ? saved : res?.results || [];

  return (
    <div>
      <div className="top">
        <span className="logo">InternLens</span>
        <div className="row">
          <span className="mut">{user.name}</span>
          <button className="btn ghost" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>{theme === "dark" ? "Light" : "Dark"}</button>
          <button className="btn ghost" onClick={onLogout}>Log out</button>
        </div>
      </div>
      <div className="grid">
        <div className="side">
          <SkillInput skills={skills} setSkills={setSkills} />
          <ResumeUpload onSkills={(l) => setSkills([...new Set([...skills, ...l])])} />
          <button className="btn" onClick={() => search()}>Find internships</button>
          {err && <div className="err" role="alert">{err}</div>}
          {res?.gaps?.length > 0 && (
            <div className="sec">
              <h3>Skills to learn next</h3>
              <div className="gap">{res.gaps.map((g) => <div key={g.skill}><span>{g.skill}</span><span className="mut">in {g.count} of your top results</span></div>)}</div>
            </div>
          )}
        </div>
        <div>
          <div className="row" style={{ justifyContent: "space-between", marginBottom: 12 }}>
            <div className="tabs" style={{ minWidth: 220 }}>
              <button className={tab === "res" ? "on" : ""} onClick={() => setTab("res")}>Results</button>
              <button className={tab === "saved" ? "on" : ""} onClick={() => setTab("saved")}>Saved ({saved.length})</button>
            </div>
            <div className="row">
              <select className="in" style={{ width: "auto" }} value={f.method} onChange={setFilter("method")} aria-label="Search method">
                <option value="hybrid">Hybrid search</option><option value="keyword">Keyword only</option>
              </select>
              <select className="in" style={{ width: "auto" }} value={f.mode} onChange={setFilter("mode")} aria-label="Work mode">
                <option value="all">Any mode</option><option>Remote</option><option>Hybrid</option><option>On-site</option>
              </select>
              <select className="in" style={{ width: "auto" }} value={f.sort} onChange={setFilter("sort")} aria-label="Sort">
                <option value="fit">Best fit</option><option value="deadline">Closest deadline</option>
              </select>
              <label className="mut"><input type="checkbox" checked={f.paid_only} onChange={setFilter("paid_only")} /> Paid only</label>
              <label className="mut"><input type="checkbox" checked={f.hide_expired} onChange={setFilter("hide_expired")} /> Hide expired</label>
            </div>
          </div>
          {loading ? (
            <div className="load" role="status">
              <div className="spin" />
              <div>{STEPS[step]}...</div>
              <div className="bar"><i /></div>
            </div>
          ) : tab === "saved" ? (
            list.length ? <div className="res">{list.map((m, i) => <ResultCard key={m.id} m={m} index={i} saved onToggle={() => toggle(m)} />)}</div>
              : <div className="load">Nothing saved yet. Save an internship from the results.</div>
          ) : !res ? (
            <div className="load"><h3>Add your skills, then search</h3><div>Matches show up here in a few milliseconds.</div></div>
          ) : (
            <div>
              <div className="mut" style={{ marginBottom: 10 }}>{res.total} internships matched in {res.took_ms} ms ({res.method} search)</div>
              {list.length ? (
                <>
                  <div className="res">{list.map((m, i) => <ResultCard key={m.id} m={m} index={i} saved={isSaved(m.id)} onToggle={() => toggle(m)} />)}</div>
                  {res.total > list.length && (
                    <div style={{ textAlign: "center", marginTop: 14 }}>
                      <button className="btn ghost" onClick={() => search(limit + PAGE)}>Show more</button>
                    </div>
                  )}
                </>
              ) : <div className="load">No matches with these filters. Try adding skills or showing expired notices.</div>}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
