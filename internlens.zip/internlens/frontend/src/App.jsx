import { useEffect, useState } from "react";
import { api, token } from "./api.js";
import Auth from "./components/Auth.jsx";
import Dashboard from "./components/Dashboard.jsx";

export default function App() {
  const [user, setUser] = useState(null);
  const [ready, setReady] = useState(false);
  const [theme, setTheme] = useState(
    localStorage.getItem("il_theme") || (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light")
  );

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    localStorage.setItem("il_theme", theme);
  }, [theme]);

  useEffect(() => {
    if (!token.get()) return setReady(true);
    api.me().then(setUser).catch(() => token.clear()).finally(() => setReady(true));
  }, []);

  if (!ready) return null;
  if (!user) return <Auth onLogin={setUser} />;
  return <Dashboard user={user} theme={theme} setTheme={setTheme} onLogout={() => { token.clear(); setUser(null); }} />;
}
