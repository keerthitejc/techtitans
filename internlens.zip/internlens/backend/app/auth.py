"""SQLite users + JWT auth. Passwords use PBKDF2-SHA256 with a per-user salt."""
import hashlib, hmac, json, os, secrets, sqlite3, time
from pathlib import Path

import jwt
from fastapi import Header, HTTPException

DB = Path(__file__).resolve().parent.parent / "data" / "app.db"
SECRET = os.environ.get("INTERNLENS_SECRET", "dev-secret-change-me")


def conn():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c


def init_db():
    with conn() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY, email TEXT UNIQUE, name TEXT, salt TEXT, hash TEXT,
            year INTEGER, cgpa REAL, branch TEXT, skills TEXT DEFAULT '[]')""")
        c.execute("CREATE TABLE IF NOT EXISTS saved(user_id INTEGER, notice_id TEXT, PRIMARY KEY(user_id, notice_id))")


def _hash(pw, salt):
    return hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 120_000).hex()


def create_user(email, name, pw, year, cgpa, branch):
    salt = secrets.token_hex(16)
    try:
        with conn() as c:
            c.execute("INSERT INTO users(email,name,salt,hash,year,cgpa,branch) VALUES(?,?,?,?,?,?,?)",
                      (email, name, salt, _hash(pw, salt), year, cgpa, branch))
    except sqlite3.IntegrityError:
        raise HTTPException(409, "This email already has an account. Log in instead.")


def verify(email, pw):
    with conn() as c:
        u = c.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    if not u or not hmac.compare_digest(u["hash"], _hash(pw, u["salt"])):
        raise HTTPException(401, "Email or password is incorrect.")
    return u


def public(u):
    return {"id": u["id"], "email": u["email"], "name": u["name"], "year": u["year"], "cgpa": u["cgpa"],
            "branch": u["branch"], "skills": json.loads(u["skills"] or "[]")}


def make_token(u):
    return jwt.encode({"sub": str(u["id"]), "exp": int(time.time()) + 7 * 86400}, SECRET, algorithm="HS256")


def current_user(authorization: str = Header(default="")):
    try:
        uid = int(jwt.decode(authorization.removeprefix("Bearer "), SECRET, algorithms=["HS256"])["sub"])
    except Exception:
        raise HTTPException(401, "Please log in again.")
    with conn() as c:
        u = c.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    if not u:
        raise HTTPException(401, "Account not found.")
    return u
