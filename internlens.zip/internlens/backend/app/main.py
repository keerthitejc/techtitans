import json
from typing import List

from fastapi import Depends, FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from . import auth, matching
from .data import get_store
from .resume import extract_text

app = FastAPI(title="InternLens API")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173"], allow_methods=["*"], allow_headers=["*"])


@app.on_event("startup")
def startup():
    auth.init_db()
    get_store()


class Signup(BaseModel):
    name: str = Field(min_length=1)
    email: str
    password: str = Field(min_length=6)
    year: int = 3
    cgpa: float = 0
    branch: str = ""


class Login(BaseModel):
    email: str
    password: str


class SearchReq(BaseModel):
    skills: List[str]
    mode: str = "all"
    paid_only: bool = False
    hide_expired: bool = True
    sort: str = "fit"           # fit | deadline
    method: str = "hybrid"      # hybrid | keyword
    limit: int = 20
    offset: int = 0


class SkillsReq(BaseModel):
    skills: List[str]


class TextReq(BaseModel):
    text: str


@app.post("/api/auth/signup")
def signup(b: Signup):
    auth.create_user(b.email.strip().lower(), b.name.strip(), b.password, b.year, b.cgpa, b.branch)
    u = auth.verify(b.email.strip().lower(), b.password)
    return {"token": auth.make_token(u), "user": auth.public(u)}


@app.post("/api/auth/login")
def login(b: Login):
    u = auth.verify(b.email.strip().lower(), b.password)
    return {"token": auth.make_token(u), "user": auth.public(u)}


@app.get("/api/me")
def me(u=Depends(auth.current_user)):
    return auth.public(u)


@app.put("/api/me/skills")
def save_skills(b: SkillsReq, u=Depends(auth.current_user)):
    with auth.conn() as c:
        c.execute("UPDATE users SET skills=? WHERE id=?", (json.dumps(b.skills), u["id"]))
    return {"ok": True}


@app.get("/api/skills")
def skills(q: str = "", exclude: str = ""):
    return get_store().tax.suggest(q, exclude=[e for e in exclude.split(",") if e])


@app.post("/api/skills/parse")
def parse_text(b: TextReq, u=Depends(auth.current_user)):
    return {"skills": get_store().tax.parse(b.text)}


@app.post("/api/resume")
async def resume(file: UploadFile = File(...), u=Depends(auth.current_user)):
    data = await file.read()
    if len(data) > 5_000_000:
        raise HTTPException(413, "File is larger than 5 MB.")
    try:
        text = extract_text(file.filename or "", data)
    except Exception:
        raise HTTPException(400, "Could not read this file. Try a text-based PDF, DOCX or TXT.")
    found = get_store().tax.parse(text)
    return {"skills": found, "characters": len(text),
            "warning": "" if text.strip() else "No text found. Scanned resumes need OCR (Tesseract)."}


@app.post("/api/search")
def search(b: SearchReq, u=Depends(auth.current_user)):
    store = get_store()
    have = sorted({store.tax.normalize(s) or s for s in b.skills})
    profile = {"cgpa": u["cgpa"], "year": u["year"], "branch": u["branch"]}
    return matching.search(store, have, profile, b.mode, b.paid_only, b.hide_expired, b.sort, b.method,
                           min(b.limit, 50), b.offset)


@app.get("/api/saved")
def get_saved(u=Depends(auth.current_user)):
    store = get_store()
    have = set(json.loads(u["skills"] or "[]"))
    profile = {"cgpa": u["cgpa"], "year": u["year"], "branch": u["branch"]}
    with auth.conn() as c:
        ids = [r["notice_id"] for r in c.execute("SELECT notice_id FROM saved WHERE user_id=?", (u["id"],))]
    return [matching.card(store.by_id[i], have, profile, store) for i in ids if i in store.by_id]


@app.put("/api/saved/{notice_id}")
def save(notice_id: str, u=Depends(auth.current_user)):
    with auth.conn() as c:
        c.execute("INSERT OR IGNORE INTO saved VALUES(?,?)", (u["id"], notice_id))
    return {"ok": True}


@app.delete("/api/saved/{notice_id}")
def unsave(notice_id: str, u=Depends(auth.current_user)):
    with auth.conn() as c:
        c.execute("DELETE FROM saved WHERE user_id=? AND notice_id=?", (u["id"], notice_id))
    return {"ok": True}
