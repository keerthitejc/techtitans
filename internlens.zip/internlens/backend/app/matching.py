"""Hybrid matching: skill evidence + TF-IDF similarity + rule-based eligibility."""
import re
import time

from .data import Store


def _status(skill, have, tax, allow_related):
    if skill in have:
        return "ok"
    if allow_related and any(tax.related(h, skill) for h in have):
        return "rel"
    return "miss"


def _sentences(text):
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+|\n+", text) if s.strip()]


def _cite(rec, tax):
    """Pick the notice sentences that support the skills and deadline claims."""
    sents = _sentences(rec["text"])
    must = set(rec["must"])
    skill_s = max(sents, key=lambda s: len(must & set(tax.parse(s))), default="")
    if not must & set(tax.parse(skill_s)):
        skill_s = ""
    dl_s = next((s for s in sents if rec["deadline_text"] and rec["deadline_text"] in s), "")
    return {"skills": skill_s, "deadline": dl_s}


def card(rec, have, profile, store: Store, method="hybrid", sim=0.0, with_cite=True):
    tax = store.tax
    rel = method == "hybrid"
    must = [{"skill": s, "status": _status(s, have, tax, rel)} for s in rec["must"]]
    pref = [{"skill": s, "status": _status(s, have, tax, rel)} for s in rec["pref"]]
    n = max(len(must), 1)
    ok = sum(m["status"] == "ok" for m in must)
    part = sum(m["status"] == "rel" for m in must)
    skill_score = (ok + 0.5 * part) / n
    pref_score = (sum(p["status"] == "ok" for p in pref) / len(pref)) if pref else 0.0
    score = 0.8 * skill_score + 0.2 * pref_score
    if method == "hybrid":
        score = 0.85 * score + 0.15 * sim
    fit = "Strong skill fit" if ok == len(must) else "Partial fit" if skill_score >= 0.4 else "Low fit"
    cg = profile.get("cgpa") or 0
    cg_status = "none" if not rec["min_cgpa"] else "unknown" if not cg else "yes" if cg >= rec["min_cgpa"] else "no"
    yr = profile.get("year")
    year_status = "unknown" if not yr else "yes" if int(yr) in rec["years"] else "no"
    dl = store.days_left(rec)
    out = {
        "id": rec["id"], "org": rec["org"], "title": rec["title"], "domain": rec["domain"], "city": rec["city"],
        "mode": rec["mode"], "weeks": rec["weeks"], "stipend": rec["stipend"], "deadline": str(rec["deadline"]),
        "days_left": dl, "expired": dl < 0, "min_cgpa": rec["min_cgpa"], "years": rec["years"],
        "must": must, "pref": pref, "fit": fit, "score": round(score, 4),
        "eligibility": {"cgpa": cg_status, "year": year_status},
    }
    if with_cite:
        out["citations"] = _cite(rec, tax)
    return out


def search(store: Store, skills, profile, mode="all", paid_only=False, hide_expired=True,
           sort="fit", method="hybrid", limit=20, offset=0):
    t0 = time.perf_counter()
    have = set(skills)
    sims = store.similarity(skills) if method == "hybrid" else None
    peak = float(sims.max()) if sims is not None and sims.max() > 0 else 1.0
    rows = []
    for i, rec in enumerate(store.recs):
        if hide_expired and store.days_left(rec) < 0:
            continue
        if mode != "all" and rec["mode"] != mode:
            continue
        if paid_only and not rec["stipend"]:
            continue
        sim = float(sims[i]) / peak if sims is not None else 0.0
        c = card(rec, have, profile, store, method, sim, with_cite=False)
        if c["score"] > 0 and any(m["status"] != "miss" for m in c["must"] + c["pref"]):
            rows.append((rec, c))
    if sort == "deadline":
        rows.sort(key=lambda x: (x[1]["days_left"], -x[1]["score"]))
    else:
        rows.sort(key=lambda x: (-x[1]["score"], x[1]["days_left"]))
    results = []
    for rec, c in rows[offset: offset + limit]:
        c["citations"] = _cite(rec, store.tax)
        results.append(c)
    gaps = {}
    for _, c in rows[:30]:
        for m in c["must"]:
            if m["status"] == "miss":
                gaps[m["skill"]] = gaps.get(m["skill"], 0) + 1
    top_gaps = sorted(gaps.items(), key=lambda kv: -kv[1])[:5]
    return {
        "total": len(rows), "took_ms": round((time.perf_counter() - t0) * 1000, 1), "method": method,
        "results": results, "gaps": [{"skill": s, "count": c} for s, c in top_gaps],
    }
