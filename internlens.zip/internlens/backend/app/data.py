"""Load the notices CSV and build the TF-IDF index."""
from datetime import date
from pathlib import Path

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer

from .skills import Taxonomy

CSV = Path(__file__).resolve().parent.parent / "data" / "internship_notices_raw.csv"


def _split(v):
    return [x for x in str(v).split("|") if x and x != "nan"]


class Store:
    def __init__(self):
        df = pd.read_csv(CSV).fillna("")
        df = df[df["is_duplicate_of"] == ""].reset_index(drop=True)  # drop re-posts
        df["deadline"] = pd.to_datetime(df["deadline_iso"]).dt.date
        all_skills, recs = set(), []
        for r in df.to_dict("records"):
            must, pref = _split(r["mandatory_skills_normalized"]), _split(r["preferred_skills_normalized"])
            all_skills.update(must + pref)
            recs.append({
                "id": r["notice_id"], "org": r["organization"], "title": r["title"], "domain": r["domain"],
                "city": r["location"], "mode": r["work_mode"], "weeks": int(r["duration_weeks"] or 0),
                "stipend": int(float(r["stipend_inr_per_month"])) if r["stipend_inr_per_month"] != "" else 0,
                "deadline": r["deadline"], "deadline_text": r["deadline_text"],
                "min_cgpa": float(r["min_cgpa"]) if r["min_cgpa"] != "" else 0.0,
                "years": [int(y) for y in _split(r["eligible_years"])], "branches": _split(r["branches"]),
                "degree": r["degree"], "must": must, "pref": pref, "text": r["notice_text"],
            })
        self.recs = recs
        self.by_id = {r["id"]: r for r in recs}
        self.tax = Taxonomy(all_skills)
        self.tfidf = TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True, max_features=40000, stop_words="english")
        self.matrix = self.tfidf.fit_transform([r["text"] for r in recs])

    def days_left(self, rec):
        return (rec["deadline"] - date.today()).days

    def similarity(self, skills):
        if not skills:
            return None
        q = self.tfidf.transform([" ".join(skills)])
        return (self.matrix @ q.T).toarray().ravel()


_store = None


def get_store():
    global _store
    if _store is None:
        _store = Store()
    return _store
