"""Skill taxonomy: normalization, resume skill parsing, and related-skill lookup."""
import re

ALIASES = {
    "ml": "Machine Learning", "machine-learning": "Machine Learning", "dl": "Deep Learning",
    "js": "JavaScript", "ecmascript": "JavaScript", "dsa": "Data Structures", "k8s": "Kubernetes",
    "cpp": "C++", "reactjs": "React", "react.js": "React", "nodejs": "Node.js", "py": "Python",
    "python3": "Python", "tf": "TensorFlow", "torch": "PyTorch", "sklearn": "Scikit-learn",
    "mysql": "SQL", "postgres": "SQL", "postgresql": "SQL", "github": "Git",
    "natural language processing": "NLP", "pytorch": "PyTorch", "tensorflow": "TensorFlow",
}

# Skills in the same cluster count as "related" (never as an exact match).
CLUSTERS = [
    ["Machine Learning", "Deep Learning", "Scikit-learn", "PyTorch", "TensorFlow", "NLP",
     "Computer Vision", "OpenCV", "Transformers", "Pandas", "NumPy"],
    ["JavaScript", "TypeScript", "React", "Node.js", "HTML", "CSS", "Next.js", "REST APIs"],
    ["Java", "C++", "C", "Data Structures", "Algorithms", "OOP", "Spring Boot"],
    ["Docker", "Kubernetes", "AWS", "CI/CD", "Linux", "Bash", "Terraform", "Ansible"],
    ["SQL", "Pandas", "Excel", "Power BI", "Tableau", "Statistics", "MongoDB"],
    ["Arduino", "Raspberry Pi", "Embedded C", "Microcontrollers", "MQTT", "RTOS", "ROS"],
    ["Networking", "Cryptography", "Penetration Testing", "Wireshark", "OWASP", "Linux"],
]


class Taxonomy:
    def __init__(self, skills):
        self.canon = {s.lower(): s for s in skills}
        for alias, target in ALIASES.items():
            self.canon[alias] = target
        self.names = sorted(set(self.canon.values()))
        self._rx = [
            (re.compile(r"(?<![a-z0-9+#])" + re.escape(k) + r"(?![a-z0-9+#])", re.I), v)
            for k, v in self.canon.items()
        ]
        self._cluster = {}
        for i, cluster in enumerate(CLUSTERS):
            for s in cluster:
                self._cluster.setdefault(s, set()).add(i)

    def normalize(self, s):
        return self.canon.get(s.strip().lower())

    def parse(self, text):
        """Find known skills in free text (resume, pasted text)."""
        return sorted({v for rx, v in self._rx if rx.search(text)})

    def related(self, a, b):
        return a != b and bool(self._cluster.get(a, set()) & self._cluster.get(b, set()))

    def suggest(self, q, limit=8, exclude=()):
        q = q.lower().strip()
        ex = set(exclude)
        hits = [n for n in self.names if n not in ex and (not q or q in n.lower())]
        return sorted(hits, key=lambda n: (not n.lower().startswith(q), n))[:limit]
